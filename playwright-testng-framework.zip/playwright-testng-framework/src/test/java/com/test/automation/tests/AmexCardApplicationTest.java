package com.test.automation.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.test.automation.base.BaseTest;
import com.test.automation.pages.ApplicationFormPage;
import com.test.automation.pages.CardDetailsPage;
import com.test.automation.pages.CardsPage;
import com.test.automation.pages.HomePage;

/**
 * Test class for American Express Card Application flow
 */
public class AmexCardApplicationTest extends BaseTest {
    
    @Test(description = "Verify American Express card application process")
    public void verifyAmexCardApplication() {
        extentTest.log(Status.INFO, "Starting American Express card application test");
        
        // Get test data
        String cardName = testData.get("CardName");
        String prenom = testData.get("Prenom");
        String nom = testData.get("Nom");
        String dateNaissance = testData.get("DateNaissance");
        String email = testData.get("Email");
        String telephone = testData.get("Telephone");
        String lieuNaissance = testData.get("LieuNaissance");
        String departement = testData.get("Departement");
        String adresse = testData.get("Adresse");
        String codePostal = testData.get("CodePostal");
        String ville = testData.get("Ville");
        String statutResidentiel = testData.get("StatutResidentiel");
        String iban = testData.get("IBAN");
        String bic = testData.get("BIC");
        String ancienneteBancaire = testData.get("AncienneteBancaire");
        String revenus = testData.get("Revenus");
        String patrimoine = testData.get("Patrimoine");
        String categorie = testData.get("Categorie");
        String profession = testData.get("Profession");
        String secteur = testData.get("Secteur");
        String employeur = testData.get("Employeur");
        String anciennete = testData.get("Anciennete");
        String nomMere = testData.get("NomMere");
        String pin = testData.get("PIN");
        
        // Initialize HomePage
        HomePage homePage = new HomePage(page);
        
        // Step 1: Validate American Express logo is appeared top left corner
        extentTest.log(Status.INFO, "Step 1: Validate American Express logo is appeared top left corner");
        boolean isLogoDisplayed = homePage.isAmexLogoDisplayed();
        Assert.assertTrue(isLogoDisplayed, "American Express logo should be displayed");
        
        // Step 2: Click on "Cartes Particuliers" link
        extentTest.log(Status.INFO, "Step 2: Click on 'Cartes Particuliers' link");
        CardsPage cardsPage = homePage.clickCartesParticuliersLink();
        
        // Step 3: Verify "Votre Sélection de Cartes" appeared in GUI
        extentTest.log(Status.INFO, "Step 3: Verify 'Votre Sélection de Cartes' appeared in GUI");
        boolean isSelectionTextDisplayed = cardsPage.isVotreSélectionDeCartesDisplayed();
        Assert.assertTrue(isSelectionTextDisplayed, "'Votre Sélection de Cartes' text should be displayed");
        
        // Step 4: Click on "En savoir plus" link under specific card
        extentTest.log(Status.INFO, "Step 4: Click on 'En savoir plus' link under " + cardName);
        CardDetailsPage cardDetailsPage = cardsPage.clickEnSavoirPlusLink(cardName);
        
        // Step 5: Verify specific card name appears in GUI
        extentTest.log(Status.INFO, "Step 5: Verify '" + cardName + "' appears in GUI");
        boolean isCardNameDisplayed = cardDetailsPage.verifyCardName(cardName);
        Assert.assertTrue(isCardNameDisplayed, "Card name '" + cardName + "' should be displayed");
        
        // Step 6: Click on "Demandez votre Carte" link
        extentTest.log(Status.INFO, "Step 6: Click on 'Demandez votre Carte' link");
        ApplicationFormPage applicationFormPage = cardDetailsPage.clickDemandezVotreCarteLink();
        
        // Step 7: Verify "Souscrivez en quelques minutes" text appears in GUI
        extentTest.log(Status.INFO, "Step 7: Verify 'Souscrivez en quelques minutes' appears in GUI");
        boolean isSouscrivezDisplayed = applicationFormPage.isSouscrivezTextDisplayed();
        Assert.assertTrue(isSouscrivezDisplayed, "'Souscrivez en quelques minutes' text should be displayed");
        
        // Step 8: Fill initial form with personal details
        extentTest.log(Status.INFO, "Step 8: Fill the initial form with personal details");
        applicationFormPage.fillInitialForm(prenom, nom, dateNaissance, email, telephone);
        
        // Step 9: Click on "Sauvegarder et Continuer" button
        extentTest.log(Status.INFO, "Step 9: Click on 'Sauvegarder et Continuer' button");
        applicationFormPage.clickSauvegarderContinuer();
        
        // Step 10: Verify "Vos informations personnelles" appears in GUI
        extentTest.log(Status.INFO, "Step 10: Verify 'Vos informations personnelles' appears in GUI");
        boolean isPersonalInfoDisplayed = applicationFormPage.isInformationsPersonellesDisplayed();
        Assert.assertTrue(isPersonalInfoDisplayed, "'Vos informations personnelles' text should be displayed");
        
        // Step 11: Fill personal information form
        extentTest.log(Status.INFO, "Step 11: Fill personal information form");
        applicationFormPage.fillPersonalInfoForm(lieuNaissance, departement, adresse, codePostal, ville, statutResidentiel);
        
        // Step 12: Click on "Sauvegarder et Continuer" button
        extentTest.log(Status.INFO, "Step 12: Click on 'Sauvegarder et Continuer' button");
        applicationFormPage.clickSauvegarderContinuer();
        
        // Step 13: Verify "Vos informations financières" appears in GUI
        extentTest.log(Status.INFO, "Step 13: Verify 'Vos informations financières' appears in GUI");
        boolean isFinancialInfoDisplayed = applicationFormPage.isInformationsFinancieresDisplayed();
        Assert.assertTrue(isFinancialInfoDisplayed, "'Vos informations financières' text should be displayed");
        
        // Step 14: Fill financial information form
        extentTest.log(Status.INFO, "Step 14: Fill financial information form");
        applicationFormPage.fillFinancialInfoForm(iban, bic, ancienneteBancaire, revenus, patrimoine, 
                                               categorie, profession, secteur, employeur, anciennete);
        
        // Step 15: Click on "Sauvegarder et Continuer" button
        extentTest.log(Status.INFO, "Step 15: Click on 'Sauvegarder et Continuer' button");
        applicationFormPage.clickSauvegarderContinuer();
        
        // Step 16: Verify "Vos informations de sécurité" appears in GUI
        extentTest.log(Status.INFO, "Step 16: Verify 'Vos informations de sécurité' appears in GUI");
        boolean isSecurityInfoDisplayed = applicationFormPage.isInformationsSecuriteDisplayed();
        Assert.assertTrue(isSecurityInfoDisplayed, "'Vos informations de sécurité' text should be displayed");
        
        // Step 17: Fill security information form
        extentTest.log(Status.INFO, "Step 17: Fill security information form");
        applicationFormPage.fillSecurityInfoForm(nomMere, pin);
        
        // Step 18: Click on "Soumettre" button
        extentTest.log(Status.INFO, "Step 18: Click on 'Soumettre' button");
        applicationFormPage.clickSoumettre();
        
        // Step 19: Verify "Merci de patienter" text appears in GUI
        extentTest.log(Status.INFO, "Step 19: Verify 'Merci de patienter' text appears in GUI");
        boolean isPatientezDisplayed = applicationFormPage.isPatientezTextDisplayed();
        Assert.assertTrue(isPatientezDisplayed, "'Merci de patienter' text should be displayed");
        
        // Step 20: Verify "Votre dossier a été pré-approuvé" text appears in GUI
        extentTest.log(Status.INFO, "Step 20: Verify 'Votre dossier a été pré-approuvé' text appears in GUI");
        boolean isPreApproveDisplayed = applicationFormPage.isPreApproveTextDisplayed();
        Assert.assertTrue(isPreApproveDisplayed, "'Votre dossier a été pré-approuvé' text should be displayed");
        
        // Step 21: Take screenshot and save it
        extentTest.log(Status.INFO, "Step 21: Take screenshot and save it");
        String screenshotPath = applicationFormPage.takeScreenshot("application_approval");
        extentTest.addScreenCaptureFromPath(screenshotPath);
        
        extentTest.log(Status.INFO, "Test completed successfully");
    }
}