package com.test.automation.base;

import com.microsoft.playwright.Page;
import com.test.automation.config.Configuration;
import com.test.automation.util.LoggerUtil;

/**
 * Base class for all Page Objects
 */
public abstract class BasePage {
    protected Page page;
    protected Configuration config;
    protected final int DEFAULT_TIMEOUT;

    public BasePage(Page page) {
        this.page = page;
        this.config = Configuration.getInstance();
        this.DEFAULT_TIMEOUT = config.getDefaultTimeout();
        LoggerUtil.info("Initialized " + this.getClass().getSimpleName());
    }

    /**
     * Wait for page load to complete
     */
    public void waitForPageLoad() {
        page.waitForLoadState();
    }

    /**
     * Check if element is visible
     * @param selector XPath selector
     * @return true if element is visible
     */
    public boolean isElementVisible(String selector) {
        try {
            return page.locator(selector).isVisible();
        } catch (Exception e) {
            LoggerUtil.error("Error checking element visibility: " + selector, e);
            return false;
        }
    }

    /**
     * Get text of an element
     * @param selector XPath selector
     * @return text of the element
     */
    public String getElementText(String selector) {
        try {
            return page.locator(selector).innerText();
        } catch (Exception e) {
            LoggerUtil.error("Error getting element text: " + selector, e);
            return "";
        }
    }

    /**
     * Click on an element
     * @param selector XPath selector
     */
    public void click(String selector) {
        try {
            page.locator(selector).click();
            LoggerUtil.info("Clicked on element: " + selector);
        } catch (Exception e) {
            LoggerUtil.error("Error clicking element: " + selector, e);
            throw e;
        }
    }

    /**
     * Fill text in an input field
     * @param selector XPath selector
     * @param text text to fill
     */
    public void fill(String selector, String text) {
        try {
            page.locator(selector).fill(text);
            LoggerUtil.info("Filled text in element: " + selector + " with value: " + text);
        } catch (Exception e) {
            LoggerUtil.error("Error filling element: " + selector, e);
            throw e;
        }
    }

    /**
     * Select option from dropdown
     * @param selector XPath selector
     * @param value value to select
     */
    public void selectOption(String selector, String value) {
        try {
            page.locator(selector).selectOption(value);
            LoggerUtil.info("Selected option in element: " + selector + " with value: " + value);
        } catch (Exception e) {
            LoggerUtil.error("Error selecting option in element: " + selector, e);
            throw e;
        }
    }

    /**
     * Check if text is present on page
     * @param text text to check
     * @return true if text is present
     */
    public boolean isTextPresent(String text) {
        try {
            return page.locator("text=" + text).isVisible();
        } catch (Exception e) {
            LoggerUtil.error("Error checking text presence: " + text, e);
            return false;
        }
    }

    /**
     * Take screenshot
     * @param name screenshot name
     * @return path to screenshot
     */
    public String takeScreenshot(String name) {
        String path = config.getScreenshotPath() + name + "_" + System.currentTimeMillis() + ".png";
        try {
            page.screenshot(new Page.ScreenshotOptions().setPath(path)); 
            LoggerUtil.info("Screenshot taken: " + path);
            return path;
        } catch (Exception e) {
            LoggerUtil.error("Error taking screenshot", e);
            return "";
        }
    }
}