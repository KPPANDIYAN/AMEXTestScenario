package com.test.automation.base;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.test.automation.config.Configuration;
import com.test.automation.util.ExcelDataProvider;
import com.test.automation.util.ExtentReportManager;
import com.test.automation.util.LoggerUtil;
import com.test.automation.util.TestDataManager;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;

/**
 * Base class for all Test classes
 */
public abstract class BaseTest {
    protected static Playwright playwright;
    protected Browser browser;
    protected BrowserContext context;
    protected Page page;
    protected Configuration config;
    protected TestDataManager testDataManager;
    protected HashMap<String, String> testData;
    protected static ExtentReports extentReports;
    protected ExtentTest extentTest;

    @BeforeSuite
    public void beforeSuite() {
        // Initialize configuration
        config = Configuration.getInstance();
        
        // Create directories for reports and screenshots
        new File(config.getReportsPath()).mkdirs();
        new File(config.getScreenshotPath()).mkdirs();
        
        // Initialize Extent Reports
        extentReports = ExtentReportManager.getInstance();
        
        // Initialize Playwright
        playwright = Playwright.create();
        
        // Initialize test data manager
        testDataManager = new TestDataManager();
        testDataManager.loadTestData(config.getTestDataPath() + config.getProperty("testDataFile"));
        
        LoggerUtil.info("Test Suite initialized");
    }

    @BeforeMethod
    public void beforeMethod(Method method) {
        // Create test in ExtentReports
        extentTest = extentReports.createTest(method.getName());
        LoggerUtil.info("Starting test: " + method.getName());
        
        // Get test data for the current test
        testData = testDataManager.getTestData(method.getName());
        
        // Launch browser
        launchBrowser();
        
        // Navigate to base URL
        navigateToBaseURL();
    }

    @AfterMethod
    public void afterMethod(ITestResult result) {
        // Update test status in ExtentReports
        if (result.getStatus() == ITestResult.FAILURE) {
            String screenshotPath = takeScreenshot(result.getName() + "_failure");
            extentTest.log(Status.FAIL, result.getThrowable());
            extentTest.addScreenCaptureFromPath(screenshotPath);
            LoggerUtil.error("Test failed: " + result.getName(), result.getThrowable());
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            extentTest.log(Status.PASS, "Test passed");
            LoggerUtil.info("Test passed: " + result.getName());
        } else {
            extentTest.log(Status.SKIP, "Test skipped");
            LoggerUtil.info("Test skipped: " + result.getName());
        }
        
        // Close browser
        closeBrowser();
    }

    @AfterSuite
    public void afterSuite() {
        // Close Playwright
        if (playwright != null) {
            playwright.close();
            LoggerUtil.info("Playwright closed");
        }
        
        // Flush ExtentReports
        if (extentReports != null) {
            extentReports.flush();
            LoggerUtil.info("ExtentReports flushed");
        }
    }

    /**
     * Launch browser based on configuration
     */
    protected void launchBrowser() {
        String browserType = config.getBrowser().toLowerCase();
        boolean headless = config.isHeadless();
        
        switch (browserType) {
            case "chromium":
                browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(headless)
                		.setArgs(Arrays.asList(
                				"--start-maximized",
                				"--disable-features=Translate",
                        "--disable-translate"
                    )));
                page = browser.newContext(new Browser.NewContextOptions().setViewportSize(null)).newPage();
                
                break;
            case "firefox":
                browser = playwright.firefox().launch(new BrowserType.LaunchOptions().setHeadless(headless));
                break;
            case "webkit":
                browser = playwright.webkit().launch(new BrowserType.LaunchOptions().setHeadless(headless));
                break;
            default:
                browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(headless));
        }
        
        context = browser.newContext();
        page = context.newPage();
        
        LoggerUtil.info("Browser launched: " + browserType + ", Headless: " + headless);
    }

    /**
     * Navigate to base URL
     */
    protected void navigateToBaseURL() {
        String baseUrl = config.getBaseUrl();
        page.navigate(baseUrl);
        page.waitForLoadState();
        LoggerUtil.info("Navigated to: " + baseUrl);
    }

    /**
     * Close browser
     */
    protected void closeBrowser() {
        if (page != null) {
            page.close();
            LoggerUtil.info("Page closed");
        }
        if (context != null) {
            context.close();
            LoggerUtil.info("Context closed");
        }
        if (browser != null) {
            browser.close();
            LoggerUtil.info("Browser closed");
        }
    }

    /**
     * Take screenshot
     * @param name screenshot name
     * @return path to screenshot
     */
    protected String takeScreenshot(String name) {
        String path = config.getScreenshotPath() + name + "_" + System.currentTimeMillis() + ".png";
        try {
            page.screenshot(new Page.ScreenshotOptions().setPath(path));
            LoggerUtil.info("Screenshot taken: " + path);
            return path;
        } catch (Exception e) {
            LoggerUtil.error("Error taking screenshot", e);
            return "";
        }
    }
}