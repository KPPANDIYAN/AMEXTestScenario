package com.test.automation.pages;

import com.microsoft.playwright.Page;
import com.test.automation.base.BasePage;
import com.test.automation.util.LoggerUtil;

/**
 * Page object for American Express Home Page
 */
public class HomePage extends BasePage {
    // Locators using relative XPath
    private final String amexLogoLocator = "//img[@src='https://www.aexp-static.com/cdaas/one/statics/axp-static-assets/1.8.0/package/dist/img/logos/dls-logo-bluebox-solid.svg']";
    private final String cartesParticuliersLinkLocator = "//a[@href='https://www.americanexpress.com/fr-fr/carte-de-paiement/toutes-les-cartes/']//p[.='Cartes Particuliers']";

    /**
     * Constructor
     * @param page Playwright page
     */
    public HomePage(Page page) {
        super(page);
    }

    /**
     * Verify if Amex logo is displayed in top left corner
     * @return true if logo is displayed
     */
    public boolean isAmexLogoDisplayed() {
        boolean isDisplayed = isElementVisible(amexLogoLocator);
        if (isDisplayed) {
            LoggerUtil.info("American Express logo is displayed");
        } else {
            LoggerUtil.error("American Express logo is not displayed");
        }
        return isDisplayed;
    }

    /**
     * Click on Cartes Particuliers link
     * @return CardsPage object
     */
    public CardsPage clickCartesParticuliersLink() {
        click(cartesParticuliersLinkLocator);
        page.waitForLoadState();
        LoggerUtil.info("Clicked on Cartes Particuliers link");
        return new CardsPage(page);
    }

    /**
     * Get page title
     * @return page title
     */
    public String getPageTitle() {
        return page.title();
    }
}