package com.test.automation.util;

import java.util.HashMap;
import java.util.List;

/**
 * Manages test data for test execution
 */
public class TestDataManager {
    private ExcelDataProvider excelDataProvider;
    private List<HashMap<String, String>> allTestData;

    /**
     * Load test data from Excel file
     * @param filePath path to Excel file
     */
    public void loadTestData(String filePath) {
        excelDataProvider = new ExcelDataProvider(filePath, "TestData");
        allTestData = excelDataProvider.getAllTestData();
        LoggerUtil.info("Test data loaded from: " + filePath);
    }

    /**
     * Get test data for a specific test case
     * @param testCaseName name of the test case
     * @return HashMap containing test data
     */
    public HashMap<String, String> getTestData(String testCaseName) {
        for (HashMap<String, String> testData : allTestData) {
            if (testData.containsKey("TestCaseName") && testData.get("TestCaseName").equals(testCaseName)) {
                LoggerUtil.info("Found test data for: " + testCaseName);
                return testData;
            }
        }
        LoggerUtil.warn("No test data found for: " + testCaseName);
        return new HashMap<>();
    }

    /**
     * Update test data
     * @param testCaseName name of the test case
     * @param key data key
     * @param value data value
     */
    public void updateTestData(String testCaseName, String key, String value) {
        for (int i = 0; i < allTestData.size(); i++) {
            HashMap<String, String> testData = allTestData.get(i);
            if (testData.containsKey("TestCaseName") && testData.get("TestCaseName").equals(testCaseName)) {
                testData.put(key, value);
                excelDataProvider.writeTestData(testData, i + 1); // +1 because first row is header
                LoggerUtil.info("Updated test data for: " + testCaseName + ", Key: " + key + ", Value: " + value);
                return;
            }
        }
        LoggerUtil.warn("Could not update test data. No data found for: " + testCaseName);
    }

    /**
     * Close Excel data provider
     */
    public void close() {
        if (excelDataProvider != null) {
            excelDataProvider.close();
            LoggerUtil.info("Excel data provider closed");
        }
    }
}