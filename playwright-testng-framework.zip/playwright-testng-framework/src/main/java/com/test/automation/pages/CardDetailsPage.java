package com.test.automation.pages;

import com.microsoft.playwright.Page;
import com.test.automation.base.BasePage;
import com.test.automation.util.LoggerUtil;

/**
 * Page object for Card Details Page
 */
public class CardDetailsPage extends BasePage {
    // Locators using relative XPath
    private final String cardNameHeaderLocator = "//li[contains(text(),'Carte Gold American Express')]";
    private final String demandezVotreCarteLinkLocator = "//a[contains(text(),'Demandez votre Carte')]";
    
    /**
     * Constructor
     * @param page Playwright page
     */
    public CardDetailsPage(Page page) {
        super(page);
    }
    
    /**
     * Get card name from header
     * @return card name
     */
    public String getCardName() {
        String cardName = getElementText(cardNameHeaderLocator);
        LoggerUtil.info("Card name: " + cardName);
        return cardName;
    }
    
    /**
     * Verify if card name is displayed
     * @param expectedCardName expected card name
     * @return true if card name matches
     */
    public boolean verifyCardName(String expectedCardName) {
        String actualCardName = getCardName();
        boolean isMatch = actualCardName.contains(expectedCardName);
        if (isMatch) {
            LoggerUtil.info("Card name matches: " + expectedCardName);
        } else {
            LoggerUtil.error("Card name does not match. Expected: " + expectedCardName + ", Actual: " + actualCardName);
        }
        return isMatch;
    }
    
    /**
     * Click on "Demandez votre Carte" link
     * @return ApplicationFormPage object
     */
    public ApplicationFormPage clickDemandezVotreCarteLink() {
        click(demandezVotreCarteLinkLocator);
        page.waitForLoadState();
        LoggerUtil.info("Clicked on 'Demandez votre Carte' link");
        return new ApplicationFormPage(page);
    }
}