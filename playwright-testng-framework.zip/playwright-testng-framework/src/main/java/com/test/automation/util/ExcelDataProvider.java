package com.test.automation.util;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 * Utility class for reading and writing Excel data
 */
public class ExcelDataProvider {
    private String filePath;
    private Workbook workbook;
    private Sheet sheet;
    private List<String> columnHeaders;

    /**
     * Constructor
     * @param filePath path to Excel file
     * @param sheetName sheet name
     */
    public ExcelDataProvider(String filePath, String sheetName) {
        this.filePath = filePath;
        try {
            FileInputStream fis = new FileInputStream(filePath);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                sheet = workbook.createSheet(sheetName);
            }
            loadColumnHeaders();
            fis.close();
        } catch (IOException e) {
            LoggerUtil.error("Error loading Excel file: " + filePath, e);
            throw new RuntimeException("Error loading Excel file: " + filePath, e);
        }
    }

    /**
     * Load column headers from the first row
     */
    private void loadColumnHeaders() {
        columnHeaders = new ArrayList<>();
        Row headerRow = sheet.getRow(0);
        if (headerRow != null) {
            Iterator<Cell> cellIterator = headerRow.cellIterator();
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                columnHeaders.add(cell.getStringCellValue());
            }
        }
    }

    /**
     * Get all test data as a list of HashMaps
     * @return list of HashMaps containing test data
     */
    public List<HashMap<String, String>> getAllTestData() {
        List<HashMap<String, String>> allData = new ArrayList<>();
        int rowCount = sheet.getLastRowNum();

        for (int i = 1; i <= rowCount; i++) {
            Row row = sheet.getRow(i);
            if (row != null) {
                HashMap<String, String> dataMap = new HashMap<>();
                for (int j = 0; j < columnHeaders.size(); j++) {
                    Cell cell = row.getCell(j);
                    if (cell != null) {
                        dataMap.put(columnHeaders.get(j), getCellValueAsString(cell));
                    } else {
                        dataMap.put(columnHeaders.get(j), "");
                    }
                }
                allData.add(dataMap);
            }
        }
        return allData;
    }

    /**
     * Get test data for a specific test case
     * @param testCaseName name of the test case
     * @return HashMap containing test data
     */
    public HashMap<String, String> getTestData(String testCaseName) {
        List<HashMap<String, String>> allData = getAllTestData();
        for (HashMap<String, String> data : allData) {
            if (data.containsKey("TestCaseName") && data.get("TestCaseName").equals(testCaseName)) {
                return data;
            }
        }
        return new HashMap<>();
    }

    /**
     * Write test data to Excel file
     * @param testData HashMap containing test data
     * @param rowIndex row index to write data
     */
    public void writeTestData(HashMap<String, String> testData, int rowIndex) {
        Row row = sheet.getRow(rowIndex);
        if (row == null) {
            row = sheet.createRow(rowIndex);
        }

        for (int i = 0; i < columnHeaders.size(); i++) {
            String columnName = columnHeaders.get(i);
            if (testData.containsKey(columnName)) {
                Cell cell = row.getCell(i);
                if (cell == null) {
                    cell = row.createCell(i);
                }
                cell.setCellValue(testData.get(columnName));
            }
        }

        try {
            FileOutputStream fos = new FileOutputStream(filePath);
            workbook.write(fos);
            fos.close();
        } catch (IOException e) {
            LoggerUtil.error("Error writing to Excel file: " + filePath, e);
            throw new RuntimeException("Error writing to Excel file: " + filePath, e);
        }
    }

    /**
     * Get cell value as string
     * @param cell cell to get value from
     * @return cell value as string
     */
    private String getCellValueAsString(Cell cell) {
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getLocalDateTimeCellValue().toString();
                } else {
                    // Convert numeric value to string without scientific notation
                    double value = cell.getNumericCellValue();
                    if (value == Math.floor(value)) {
                        return String.format("%.0f", value);
                    } else {
                        return String.valueOf(value);
                    }
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            default:
                return "";
        }
    }

    /**
     * Close workbook
     */
    public void close() {
        try {
            if (workbook != null) {
                workbook.close();
            }
        } catch (IOException e) {
            LoggerUtil.error("Error closing workbook", e);
        }
    }
}