package com.test.automation.pages;

import com.microsoft.playwright.Page;
import com.test.automation.base.BasePage;
import com.test.automation.util.LoggerUtil;

/**
 * Page object for Cards Selection Page
 */
public class CardsPage extends BasePage {
    // Locators using relative XPath
    private final String votreSélectionDeCartesTextLocator = "//h1[contains(text(),'Votre Sélection de Cartes')]";
    private final String cardInfoLocatorTemplate = "//h2[contains(text(),'%s')]";
    private final String enSavoirPlusLinkTemplate = "//div[@data-qe-id='CallToActionsWithLinks']//a[contains(@href,'GoldCardAmericanExpress')]";
    
    /**
     * Constructor
     * @param page Playwright page
     */
    public CardsPage(Page page) {
        super(page);
    }
    
    /**
     * Verify if "Votre Sélection de Cartes" text is displayed
     * @return true if text is displayed
     */
    public boolean isVotreSélectionDeCartesDisplayed() {
        boolean isDisplayed = isElementVisible(votreSélectionDeCartesTextLocator);
        if (isDisplayed) {
            LoggerUtil.info("'Votre Sélection de Cartes' text is displayed");
        } else {
            LoggerUtil.error("'Votre Sélection de Cartes' text is not displayed");
        }
        return isDisplayed;
    }
    
    /**
     * Check if a specific card is displayed
     * @param cardName name of the card
     * @return true if card is displayed
     */
    public boolean isCardDisplayed(String cardName) {
        String cardLocator = String.format(cardInfoLocatorTemplate, cardName);
        boolean isDisplayed = isElementVisible(cardLocator);
        if (isDisplayed) {
            LoggerUtil.info("Card '" + cardName + "' is displayed");
        } else {
            LoggerUtil.error("Card '" + cardName + "' is not displayed");
        }
        return isDisplayed;
    }
    
    /**
     * Click on "En savoir plus" link for a specific card
     * @param cardName name of the card
     * @return CardDetailsPage object
     */
    public CardDetailsPage clickEnSavoirPlusLink(String cardName) {
        String linkLocator = String.format(enSavoirPlusLinkTemplate, cardName);
        click(linkLocator);
        page.waitForLoadState();
        LoggerUtil.info("Clicked on 'En savoir plus' link for card: " + cardName);
        return new CardDetailsPage(page);
    }
}