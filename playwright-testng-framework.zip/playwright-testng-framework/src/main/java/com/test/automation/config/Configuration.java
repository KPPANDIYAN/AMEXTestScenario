package com.test.automation.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Configuration class to manage properties and settings
 */
public class Configuration {
    private static final Properties properties = new Properties();
    private static Configuration instance;

    private Configuration() {
        try {
            FileInputStream fileInputStream = new FileInputStream("src/main/resources/config.properties");
            properties.load(fileInputStream);
            fileInputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static synchronized Configuration getInstance() {
        if (instance == null) {
            instance = new Configuration();
        }
        return instance;
    }

    public String getProperty(String key) {
        return properties.getProperty(key);
    }

    public String getProperty(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

    public String getBrowser() {
        return getProperty("browser", "chromium");
    }

    public boolean isHeadless() {
        return Boolean.parseBoolean(getProperty("headless", "false"));
    }

    public String getBaseUrl() {
        return getProperty("baseUrl", "https://www.americanexpress.com/fr-fr/");
    }

    public int getDefaultTimeout() {
        return Integer.parseInt(getProperty("defaultTimeout", "30000"));
    }

    public String getTestDataPath() {
        return getProperty("testDataPath", "src/test/resources/testdata/");
    }

    public String getScreenshotPath() {
        return getProperty("screenshotPath", "reports/screenshots/");
    }

    public String getReportsPath() {
        return getProperty("reportsPath", "reports/");
    }
}