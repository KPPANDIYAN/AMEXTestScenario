package com.test.automation.pages;

import com.microsoft.playwright.Page;
import com.test.automation.base.BasePage;
import com.test.automation.util.LoggerUtil;

/**
 * Page object for Application Form Page
 */
public class ApplicationFormPage extends BasePage {
    // Locators using relative XPath
    private final String souscrivezTextLocator = "//h1[contains(text(),'Souscrivez en quelques minutes')]";
    private final String titleMRadioLocator = "//input[@name='title' and @value='M']";
    private final String prenomInputLocator = "//input[@id='givenName']";
    private final String nomInputLocator = "//input[@id='surname']";
    private final String dateNaissanceInputLocator = "//input[@id='birthDate']";
    private final String emailInputLocator = "//input[@id='email']";
    private final String phoneInputLocator = "//input[@id='mobilePhone']";
    private final String sauvegarderContinuerButtonLocator = "//button[contains(text(),'Sauvegarder et Continuer')]";
    
    // Personal Information Section
    private final String personellesTextLocator = "//h1[contains(text(),'Vos informations personnelles')]";
    private final String nomNaissanceCheckboxLocator = "//input[@id='sameAsSurname']";
    private final String lieuNaissanceInputLocator = "//input[@id='birthCity']";
    private final String departementNaissanceInputLocator = "//input[@id='birthDepartment']";
    private final String paysNaissanceSelectLocator = "//select[@id='birthCountry']";
    private final String nationaliteSelectLocator = "//select[@id='nationality']";
    private final String paysTerritoriesSelectLocator = "//select[@id='countryTerritories']";
    private final String addressInputLocator = "//input[@id='addressLine1']";
    private final String codePostalInputLocator = "//input[@id='postalCode']";
    private final String villeInputLocator = "//input[@id='city']";
    private final String statutResidentielSelectLocator = "//select[@id='residentialStatus']";
    
    // Financial Information Section
    private final String financieresTextLocator = "//h1[contains(text(),'Vos informations financières')]";
    private final String ibanInputLocator = "//input[@id='bankAccountNumber']";
    private final String bicInputLocator = "//input[@id='bankIdentifierCode']";
    private final String ancienneteBancaireSelectLocator = "//select[@id='bankingRelationshipYears']";
    private final String revenusInputLocator = "//input[@id='income']";
    private final String autreRevenusNoRadioLocator = "//input[@name='hasOtherIncome' and @value='false']";
    private final String patrimoineSelectLocator = "//select[@id='financialAssets']";
    private final String categorieSelectLocator = "//select[@id='profession']";
    private final String professionSelectLocator = "//select[@id='jobTitle']";
    private final String secteurSelectLocator = "//select[@id='industryCode']";
    private final String employeurInputLocator = "//input[@id='employerName']";
    private final String ancienneteSelectLocator = "//select[@id='yearsOfService']";
    
    // Security Information Section
    private final String securiteTextLocator = "//h1[contains(text(),'Vos informations de sécurité')]";
    private final String nomMereInputLocator = "//input[@id='mothersMaidenName']";
    private final String pinInputLocator = "//input[@id='pin']";
    private final String confirmPinInputLocator = "//input[@id='confirmPin']";
    private final String emailNonRadioLocator = "//input[@name='optInEmail' and @value='false']";
    private final String smsNonRadioLocator = "//input[@name='optInOther' and @value='false']";
    private final String soumettreButtonLocator = "//button[contains(text(),'Soumettre')]";
    
    // Approval Section
    private final String patientezTextLocator = "//div[contains(text(),'Merci de patienter')]";
    private final String preApproveTextLocator = "//div[contains(text(),'Votre dossier a été pré-approuvé')]";
    
    /**
     * Constructor
     * @param page Playwright page
     */
    public ApplicationFormPage(Page page) {
        super(page);
    }
    
    /**
     * Verify if "Souscrivez en quelques minutes" text is displayed
     * @return true if text is displayed
     */
    public boolean isSouscrivezTextDisplayed() {
        boolean isDisplayed = isElementVisible(souscrivezTextLocator);
        if (isDisplayed) {
            LoggerUtil.info("'Souscrivez en quelques minutes' text is displayed");
        } else {
            LoggerUtil.error("'Souscrivez en quelques minutes' text is not displayed");
        }
        return isDisplayed;
    }
    
    /**
     * Fill initial application form
     * @param prenom first name
     * @param nom last name
     * @param dateNaissance date of birth
     * @param email email address
     * @param phone phone number
     * @return this ApplicationFormPage
     */
    public ApplicationFormPage fillInitialForm(String prenom, String nom, String dateNaissance, String email, String phone) {
        click(titleMRadioLocator);
        fill(prenomInputLocator, prenom);
        fill(nomInputLocator, nom);
        fill(dateNaissanceInputLocator, dateNaissance);
        fill(emailInputLocator, email);
        fill(phoneInputLocator, phone);
        LoggerUtil.info("Filled initial application form");
        return this;
    }
    
    /**
     * Click on Sauvegarder et Continuer button
     * @return this ApplicationFormPage
     */
    public ApplicationFormPage clickSauvegarderContinuer() {
        click(sauvegarderContinuerButtonLocator);
        page.waitForLoadState();
        LoggerUtil.info("Clicked on Sauvegarder et Continuer button");
        return this;
    }
    
    /**
     * Verify if "Vos informations personnelles" text is displayed
     * @return true if text is displayed
     */
    public boolean isInformationsPersonellesDisplayed() {
        boolean isDisplayed = isElementVisible(personellesTextLocator);
        if (isDisplayed) {
            LoggerUtil.info("'Vos informations personnelles' text is displayed");
        } else {
            LoggerUtil.error("'Vos informations personnelles' text is not displayed");
        }
        return isDisplayed;
    }
    
    /**
     * Fill personal information form
     * @param lieuNaissance place of birth
     * @param departement department of birth
     * @param address address
     * @param codePostal postal code
     * @param ville city
     * @param statutResidentiel residential status
     * @return this ApplicationFormPage
     */
    public ApplicationFormPage fillPersonalInfoForm(String lieuNaissance, String departement, String address, String codePostal, String ville, String statutResidentiel) {
        click(nomNaissanceCheckboxLocator);
        fill(lieuNaissanceInputLocator, lieuNaissance);
        fill(departementNaissanceInputLocator, departement);
        fill(addressInputLocator, address);
        fill(codePostalInputLocator, codePostal);
        fill(villeInputLocator, ville);
        selectOption(statutResidentielSelectLocator, statutResidentiel);
        LoggerUtil.info("Filled personal information form");
        return this;
    }
    
    /**
     * Verify if "Vos informations financières" text is displayed
     * @return true if text is displayed
     */
    public boolean isInformationsFinancieresDisplayed() {
        boolean isDisplayed = isElementVisible(financieresTextLocator);
        if (isDisplayed) {
            LoggerUtil.info("'Vos informations financières' text is displayed");
        } else {
            LoggerUtil.error("'Vos informations financières' text is not displayed");
        }
        return isDisplayed;
    }
    
    /**
     * Fill financial information form
     * @param iban IBAN
     * @param bic BIC
     * @param ancienneteBancaire banking relationship years
     * @param revenus income
     * @param patrimoine financial assets
     * @param categorie profession category
     * @param profession profession
     * @param secteur industry sector
     * @param employeur employer name
     * @param anciennete years of service
     * @return this ApplicationFormPage
     */
    public ApplicationFormPage fillFinancialInfoForm(String iban, String bic, String ancienneteBancaire, String revenus, 
                                                  String patrimoine, String categorie, String profession, 
                                                  String secteur, String employeur, String anciennete) {
        fill(ibanInputLocator, iban);
        fill(bicInputLocator, bic);
        selectOption(ancienneteBancaireSelectLocator, ancienneteBancaire);
        fill(revenusInputLocator, revenus);
        click(autreRevenusNoRadioLocator);
        selectOption(patrimoineSelectLocator, patrimoine);
        selectOption(categorieSelectLocator, categorie);
        selectOption(professionSelectLocator, profession);
        selectOption(secteurSelectLocator, secteur);
        fill(employeurInputLocator, employeur);
        selectOption(ancienneteSelectLocator, anciennete);
        LoggerUtil.info("Filled financial information form");
        return this;
    }
    
    /**
     * Verify if "Vos informations de sécurité" text is displayed
     * @return true if text is displayed
     */
    public boolean isInformationsSecuriteDisplayed() {
        boolean isDisplayed = isElementVisible(securiteTextLocator);
        if (isDisplayed) {
            LoggerUtil.info("'Vos informations de sécurité' text is displayed");
        } else {
            LoggerUtil.error("'Vos informations de sécurité' text is not displayed");
        }
        return isDisplayed;
    }
    
    /**
     * Fill security information form
     * @param nomMere mother's maiden name
     * @param pin PIN
     * @return this ApplicationFormPage
     */
    public ApplicationFormPage fillSecurityInfoForm(String nomMere, String pin) {
        fill(nomMereInputLocator, nomMere);
        fill(pinInputLocator, pin);
        fill(confirmPinInputLocator, pin);
        click(emailNonRadioLocator);
        click(smsNonRadioLocator);
        LoggerUtil.info("Filled security information form");
        return this;
    }
    
    /**
     * Click on Soumettre button
     * @return this ApplicationFormPage
     */
    public ApplicationFormPage clickSoumettre() {
        click(soumettreButtonLocator);
        page.waitForLoadState();
        LoggerUtil.info("Clicked on Soumettre button");
        return this;
    }
    
    /**
     * Verify if "Merci de patienter" text is displayed
     * @return true if text is displayed
     */
    public boolean isPatientezTextDisplayed() {
        boolean isDisplayed = isTextPresent("Merci de patienter, nous traitons votre demande.");
        if (isDisplayed) {
            LoggerUtil.info("'Merci de patienter' text is displayed");
        } else {
            LoggerUtil.error("'Merci de patienter' text is not displayed");
        }
        return isDisplayed;
    }
    
    /**
     * Verify if "Votre dossier a été pré-approuvé" text is displayed
     * @return true if text is displayed
     */
    public boolean isPreApproveTextDisplayed() {
        boolean isDisplayed = isTextPresent("Votre dossier a été pré-approuvé.");
        if (isDisplayed) {
            LoggerUtil.info("'Votre dossier a été pré-approuvé' text is displayed");
        } else {
            LoggerUtil.error("'Votre dossier a été pré-approuvé' text is not displayed");
        }
        return isDisplayed;
    }
}