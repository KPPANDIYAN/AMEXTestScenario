package com.test.automation.util;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.test.automation.config.Configuration;

/**
 * Manages ExtentReports for test reporting
 */
public class ExtentReportManager {
    private static ExtentReports extentReports;

    private ExtentReportManager() {
        // Private constructor to prevent instantiation
    }

    /**
     * Get instance of ExtentReports
     * @return ExtentReports instance
     */
    public static synchronized ExtentReports getInstance() {
        if (extentReports == null) {
            extentReports = createExtentReports();
        }
        return extentReports;
    }

    /**
     * Create ExtentReports
     * @return ExtentReports instance
     */
    private static ExtentReports createExtentReports() {
        Configuration config = Configuration.getInstance();
        String reportPath = config.getReportsPath() + "AmexTestReport_" + System.currentTimeMillis() + ".html";
        
        ExtentReports extentReports = new ExtentReports();
        ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
        
        // Configure report appearance
        sparkReporter.config().setTheme(Theme.STANDARD);
        sparkReporter.config().setDocumentTitle("Amex Test Automation Report");
        sparkReporter.config().setReportName("American Express Test Results");
        sparkReporter.config().setTimeStampFormat("yyyy-MM-dd HH:mm:ss");
        
        // Add system info
        extentReports.attachReporter(sparkReporter);
        extentReports.setSystemInfo("Browser", config.getBrowser());
        extentReports.setSystemInfo("Headless", String.valueOf(config.isHeadless()));
        extentReports.setSystemInfo("Environment", "Test");
        extentReports.setSystemInfo("Operating System", System.getProperty("os.name"));
        extentReports.setSystemInfo("Java Version", System.getProperty("java.version"));
        
        LoggerUtil.info("ExtentReports initialized: " + reportPath);
        return extentReports;
    }
}